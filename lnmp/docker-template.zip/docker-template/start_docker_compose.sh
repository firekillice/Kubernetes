CURRENT_UID=0:0 docker-compose up -d 
docker ps
#docker rm $(docker ps -aq) 
#docker stop $(docker ps -q) & docker rm $(docker ps -aq)
